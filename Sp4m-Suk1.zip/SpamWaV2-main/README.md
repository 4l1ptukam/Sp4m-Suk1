# SpamWaV2
SpamWA is a script tool used to provide a spam otp on the victim's number

# Installation 

pkg update && pkg upgrade

pkg install python python3

git clone https://github.com/Himalagle-exc27/SpamWaV2

cd SpamWaV2

python3 main.py

# About 
This script tools is made by me Himalaglebruhv

Visit me on these platform 👇🏻

Youtube : 

WhatsApp : https://wa.me/+6283181616755

Github : https://github.com/4l1ptukam
